# SVA Compagnon — Guide de déploiement Netlify

## Structure du projet

```
sva-app/
├── index.html                  ← L'application frontend
├── netlify.toml                ← Configuration Netlify
├── .env.example                ← Variables à configurer
└── netlify/
    └── functions/
        └── sva.js              ← Backend sécurisé (clé API ici)
```

## Déploiement en 4 étapes

### 1. Créer un dépôt GitHub
Mettez tous ces fichiers dans un dépôt GitHub (public ou privé).

### 2. Connecter à Netlify
- Allez sur [netlify.com](https://netlify.com)
- "Add new site" → "Import an existing project"
- Connectez votre dépôt GitHub
- Build settings : laissez tout vide (pas de commande de build)
- Cliquez "Deploy"

### 3. Configurer les variables d'environnement
Dans Netlify → Site settings → Environment variables, ajoutez :

| Variable | Valeur |
|----------|--------|
| `ANTHROPIC_API_KEY` | Votre clé `sk-ant-...` |
| `ALLOWED_ORIGIN` | `https://votre-site.netlify.app` |

### 4. Configurer Supabase
Dans votre projet Supabase, créez la table `profiles` :

```sql
create table profiles (
  id uuid references auth.users primary key,
  first_name text,
  memory_entries jsonb default '[]',
  session_history jsonb default '[]',
  created_at timestamp with time zone default now()
);

-- Sécurité : chaque utilisateur ne voit que ses propres données
alter table profiles enable row level security;

create policy "Users can manage own profile"
  on profiles for all
  using (auth.uid() = id);
```

Activez aussi le magic link dans Supabase → Authentication → Providers → Email.

## Sécurité mise en place

- ✅ Clé Anthropic côté serveur uniquement (jamais dans le navigateur)
- ✅ Rate limiting : 30 requêtes/minute par IP
- ✅ Validation et sanitisation de tous les inputs
- ✅ Headers de sécurité (CSP, X-Frame-Options, etc.)
- ✅ CORS restrictif (uniquement votre domaine)
- ✅ RLS Supabase (chaque utilisateur ne voit que ses données)
- ✅ Chiffrement AES-256 au repos (Supabase)
- ✅ HTTPS obligatoire (Netlify)

## Phase test → Phase abonnement

En phase test (maintenant) : accès libre après inscription email.
En phase abonnement : ajouter Stripe dans `netlify/functions/sva.js`
pour vérifier le statut de l'abonnement avant chaque réponse.
