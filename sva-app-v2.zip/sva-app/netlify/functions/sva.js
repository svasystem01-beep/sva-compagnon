// ══════════════════════════════════════════════
// SVA — Backend sécurisé (Netlify Function)
// La clé API Anthropic n'est JAMAIS exposée
// au navigateur. Elle vit ici, côté serveur.
// ══════════════════════════════════════════════

const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || '*'; // ex: 'https://sva.netlify.app'
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';

// Rate limiting simple en mémoire (par IP)
const rateLimitMap = new Map();
const RATE_LIMIT = 30;        // max requêtes
const RATE_WINDOW = 60 * 1000; // par minute

function checkRateLimit(ip) {
  const now = Date.now();
  const entry = rateLimitMap.get(ip) || { count: 0, start: now };
  if (now - entry.start > RATE_WINDOW) {
    rateLimitMap.set(ip, { count: 1, start: now });
    return true;
  }
  if (entry.count >= RATE_LIMIT) return false;
  entry.count++;
  rateLimitMap.set(ip, entry);
  return true;
}

exports.handler = async (event) => {
  // ── CORS ──
  const headers = {
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  // ── Rate limiting ──
  const ip = event.headers['x-forwarded-for']?.split(',')[0]?.trim() || 'unknown';
  if (!checkRateLimit(ip)) {
    return {
      statusCode: 429,
      headers,
      body: JSON.stringify({ error: 'Trop de requêtes. Attendez un instant.' })
    };
  }

  // ── Validation clé API ──
  if (!ANTHROPIC_API_KEY) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Configuration serveur manquante.' })
    };
  }

  // ── Parse body ──
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Corps de requête invalide.' }) };
  }

  const { system, messages } = body;

  // ── Validation des inputs ──
  if (!Array.isArray(messages) || messages.length === 0) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Messages manquants.' }) };
  }

  // Sanitisation : on ne garde que role et content (strings)
  const safeMessages = messages
    .filter(m => m && typeof m.role === 'string' && typeof m.content === 'string')
    .map(m => ({ role: m.role, content: m.content.slice(0, 4000) })) // max 4000 chars par message
    .slice(-30); // max 30 messages d'historique

  if (safeMessages.length === 0) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'Messages invalides.' }) };
  }

  // ── Appel Anthropic ──
  try {
    const response = await fetch(ANTHROPIC_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: typeof system === 'string' ? system.slice(0, 8000) : '',
        messages: safeMessages,
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      console.error('Anthropic error:', err);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ error: 'Erreur du service IA.' })
      };
    }

    const data = await response.json();
    const reply = data.content?.map(b => b.text || '').join('') || '';

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ reply })
    };

  } catch (err) {
    console.error('Function error:', err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Erreur serveur. Réessayez.' })
    };
  }
};
